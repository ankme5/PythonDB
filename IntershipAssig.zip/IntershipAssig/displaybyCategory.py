import mysql.connector as mycon

con=mycon.connect(user='uw47dk21l0snllly',
host='bwh3bg1qm0ujcamxkzmu-mysql.services.clever-cloud.com',password='2aaKptci5VSwhbPlfhuI',
database='bwh3bg1qm0ujcamxkzmu')
curs=con.cursor()
category=input("Enter Category : ")
curs.execute("select bookname from book where category= '%s' "%(category))
data=curs.fetchall()
if data:
    print("Book Names ")
    for i,d in enumerate(data,1):
        print(str(i)+" "+d[0])
else:
    print("No Book Found of %s Category" %category)
