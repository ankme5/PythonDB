import mysql.connector as mycon

con=mycon.connect(user='uw47dk21l0snllly',
host='bwh3bg1qm0ujcamxkzmu-mysql.services.clever-cloud.com',password='2aaKptci5VSwhbPlfhuI',
database='bwh3bg1qm0ujcamxkzmu')
curs=con.cursor()
curs.execute("select bookname from book where author='%s' and publication='%s'" %(input("Enter Author Name : "),input("Enter Publication Name : ")))
data=curs.fetchall()
print("Books Name Are : ")
if data:
    for i,d in enumerate(data,1):
        print(str(i),d[0])
else:
    print("No Books Are Available!")