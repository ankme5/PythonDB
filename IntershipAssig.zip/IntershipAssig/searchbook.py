import mysql.connector as mycon
con=mycon.connect(user='uw47dk21l0snllly',
host='bwh3bg1qm0ujcamxkzmu-mysql.services.clever-cloud.com',password='2aaKptci5VSwhbPlfhuI',
database='bwh3bg1qm0ujcamxkzmu')
curs=con.cursor()
curs.execute("select * from book where barcode=%d" %(int(input("Enter Bookcode : "))))
data=curs.fetchall()
if data:
    print(data)
else:
    print("Not Found")
