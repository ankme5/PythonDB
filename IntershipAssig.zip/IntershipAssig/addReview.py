import mysql.connector as mycon

con=mycon.connect(user='uw47dk21l0snllly',
host='bwh3bg1qm0ujcamxkzmu-mysql.services.clever-cloud.com',password='2aaKptci5VSwhbPlfhuI',
database='bwh3bg1qm0ujcamxkzmu')
curs=con.cursor()
curs.execute("select barcode from book where barcode=%d" %(int(input("Enter Book Code : "))))
data=curs.fetchone()
if data:
    curs.execute("update book set review='%s' where barcode=%d" %(input("Enter Review : "),data[0]))
    con.commit()
    print("Review Added...")
else:
    print("No Book Found!")
