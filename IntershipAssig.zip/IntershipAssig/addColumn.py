import mysql.connector as mycon

con=mycon.connect(user='uw47dk21l0snllly',
host='bwh3bg1qm0ujcamxkzmu-mysql.services.clever-cloud.com',password='2aaKptci5VSwhbPlfhuI',
database='bwh3bg1qm0ujcamxkzmu')
curs=con.cursor()
curs.execute("alter table book add column review varchar(500)")
print("table modified successfully..")
con.commit()
con.close()