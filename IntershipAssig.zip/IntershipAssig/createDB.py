import mysql.connector as mycon
con=mycon.connect(user='uw47dk21l0snllly',
host='bwh3bg1qm0ujcamxkzmu-mysql.services.clever-cloud.com',password='2aaKptci5VSwhbPlfhuI',database='bwh3bg1qm0ujcamxkzmu')
#con=mycon.connect(host='localhost',user='root',password='root')
curs=con.cursor()
# curs.execute("create database bookstoredb")
# con.commit()
# curs.execute("use bookstoredb")
# con.commit()
curs.execute("create table book(barcode int primary key,bookname varchar(30),category varchar(20),author varchar(20),publication varchar(20),edition varchar(10),price float)")
con.commit()
print("successful")
con.close()