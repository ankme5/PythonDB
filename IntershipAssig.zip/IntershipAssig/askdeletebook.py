import mysql.connector as mycon

con=mycon.connect(user='uw47dk21l0snllly',
host='bwh3bg1qm0ujcamxkzmu-mysql.services.clever-cloud.com',password='2aaKptci5VSwhbPlfhuI',
database='bwh3bg1qm0ujcamxkzmu')
curs=con.cursor()
curs.execute("select * from book where barcode=%d" %(int(input("Enter Book Code : "))))
data=curs.fetchone()
if data:
    print(('BookCode','BookName','Cetegory','Author','Publication','Edition','Price($)'))
    print(data)
    res=input("Do You Want To Delete? : ").lower()
    if res=="yes":
        curs.execute("delete from book where barcode=%d" %data[0])
        con.commit()
        print("Data Deleted Successfully....")
    else:
        print("OK Thank You..")
else:
    print("No Book Found")