import mysql.connector as mycon

con=mycon.connect(user='uw47dk21l0snllly',
host='bwh3bg1qm0ujcamxkzmu-mysql.services.clever-cloud.com',password='2aaKptci5VSwhbPlfhuI',
database='bwh3bg1qm0ujcamxkzmu')
# con=mycon.connect(host='localhost',user='root',password='root',database='bookstoredb')
curs=con.cursor()
barcode=int(input("Enter Book code :"))
bookname=input("Enter Book Name : ")
category=input("Enter Category : ")
author=input("Enter Author : ")
publication=input("Enter Publication : ")
Edition=input("Enter Edition : ")
Price=float(input("Enter Price($): "))

curs.execute("insert into book values(%d,'%s','%s','%s','%s','%s',%.2f)"%(barcode,bookname,category,author,publication,Edition,Price))
con.commit()
print("Data Inserted Successfully")
con.close()